create function st_pixelaspoint(rast raster, x integer, y integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_PointN(ST_ExteriorRing(geom), 1) FROM public._ST_pixelaspolygons($1, NULL, $2, $3)
$$;

comment on function st_pixelaspoint(raster, integer, integer) is 'args: rast, columnx, rowy - Returns a point geometry of the pixels upper-left corner.';

alter function st_pixelaspoint(raster, integer, integer) owner to postgres;

