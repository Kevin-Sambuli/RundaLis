create view parcels_json(jsonb_build_object) as
SELECT jsonb_build_object('type', 'FeatureCollection', 'features', jsonb_agg(features.feature)) AS jsonb_build_object
FROM (SELECT jsonb_build_object('type', 'Feature', 'geometry', st_asgeojson(inputs.geom)::jsonb, 'properties',
                                to_jsonb(inputs.*) - 'geom'::text) AS feature,
             'geometry'
      FROM (SELECT parcels.id,
                   parcels.perimeter,
                   parcels.area_ha,
                   parcels.lr_no,
                   parcels.geom,
                   parcels.owner_id
            FROM parcels) inputs) features;

alter table parcels_json
    owner to postgres;

