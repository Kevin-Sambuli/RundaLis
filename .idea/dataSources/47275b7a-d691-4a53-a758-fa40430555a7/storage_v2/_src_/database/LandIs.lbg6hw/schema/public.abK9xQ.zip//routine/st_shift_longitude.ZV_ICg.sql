create function st_shift_longitude(geometry) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public._postgis_deprecate('ST_Shift_Longitude', 'ST_ShiftLongitude', '2.2.0');
    SELECT public.ST_ShiftLongitude($1);
$$;

alter function st_shift_longitude(geometry) owner to postgres;

