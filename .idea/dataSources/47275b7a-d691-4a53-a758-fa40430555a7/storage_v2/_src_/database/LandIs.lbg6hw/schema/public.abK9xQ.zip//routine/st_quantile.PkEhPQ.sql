create function st_quantile(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) returns SETOF record
    immutable
    parallel safe
    language sql
as
$$
SELECT public._ST_quantile($1, $2, $3, 1, $4)
$$;

comment on function st_quantile(raster, integer, boolean, double precision[], out double precision, out double precision) is 'args: rast, nband=1, exclude_nodata_value=true, quantiles=NULL - Compute quantiles for a raster or raster table coverage in the context of the sample or population. Thus, a value could be examined to be at the rasters 25%, 50%, 75% percentile.';

alter function st_quantile(raster, integer, boolean, double precision[], out double precision, out double precision) owner to postgres;

