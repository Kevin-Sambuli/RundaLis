create function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.ST_Affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)
$$;

comment on function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) is 'args: geomA, a, b, d, e, xoff, yoff - Apply a 3d affine transformation to a geometry.';

alter function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) owner to postgres;

