create function st_touches(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Touches($1,$2)
$$;

comment on function st_touches(geometry, geometry) is 'args: g1, g2 - Returns TRUE if the geometries have at least one point in common, but their interiors do not intersect.';

alter function st_touches(geometry, geometry) owner to postgres;

